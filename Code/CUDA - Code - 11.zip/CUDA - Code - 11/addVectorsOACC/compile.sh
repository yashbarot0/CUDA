/opt/pgi/linux86-64/19.10/bin/pgcc -acc addVectorsOACC.c
