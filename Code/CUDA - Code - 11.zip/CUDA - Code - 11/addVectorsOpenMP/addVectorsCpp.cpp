#include "stdio.h"
#include <cstdlib>

#include <omp.h>

#define N 1000

int main() {
	// pointers to host memory
//	int N=1000;

	int i;

	// Allocate arrays a, b and c on host
//	float a[N], b[N], c[N];
	float *a, *b, *c;
	a = (float*) malloc(N*sizeof(float));
	b = (float*) malloc(N*sizeof(float));
	c = (float*) malloc(N*sizeof(float));

	// Initialize arrays a and b
	for (i=0; i<N; i++) {
		a[i]= (float) i;
		b[i]=+(float) 2*i;
	}

	// Add the arrays
//#pragma omp parallel	// Standard CPU-based OpenMP
#pragma omp target map(tofrom: a[0:N], b[0:N], c[0:N])
	for (i=0; i<N; i++) {
		c[i]= a[i]+b[i];
	}

	// Print c
	printf("addVectorsfloat will generate two vectors, move them to the global memory, and add them together in the GPU\n");
	for (i=0; i<N; i++) {
		printf(" a[%2d](%10f) + b[%2d](%10f) = c[%2d](%10f)\n",i,a[i],i,b[i],i,c[i]);
	}

	// Free the memory
	free(a); free(b); free(c);

}
