

//extern inline int add_vectors(void);

#include "add_vectors.h"

int main ()  {
	add_vectors();
}
