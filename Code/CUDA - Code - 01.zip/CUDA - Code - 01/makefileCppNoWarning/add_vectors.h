//#ifdef __cplusplus
//extern "C" {
	int add_vectors();
//}
//#endif
