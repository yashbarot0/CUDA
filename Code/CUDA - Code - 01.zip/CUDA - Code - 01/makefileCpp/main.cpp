
extern inline int add_vectors(void);

int main ()  {
	add_vectors();
}
