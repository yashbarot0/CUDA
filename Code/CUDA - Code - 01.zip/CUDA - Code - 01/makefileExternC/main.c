
#include "add_vectors.h"

extern int add_vectors(void);

int main ()  {
	add_vectors();
	return 0;
}
