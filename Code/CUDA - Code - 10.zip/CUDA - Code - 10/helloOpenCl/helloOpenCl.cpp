#include <utility>
#define __NO_STD_VECTOR // Use cl::vector instead of STL version
#include <CL/cl.h>
#include <CL/cl.hpp>
//#include </usr/include/CL/>

#include <cstdio>
#include <cstdlib>
#include <fstream>
#include <iostream>
#include <string>
#include <iterator>

#include <iostream>
#include <vector>

//using namespace cl;

using namespace std;

inline void checkErr(cl_int err, const char * name) {
	if (err != CL_SUCCESS) {
		std::cerr << "ERROR: " << name << " (" << err << ")" << std::endl;
		exit(EXIT_FAILURE);
	}
}

int main () {
	const std::string hw("Hello World\n");

	cl_int err;
	cl::vector< cl::Platform > platformList;
	cl::Platform::get(&platformList);
	cout << "platformList.size()=" << platformList.size() << endl;
	if (platformList.empty()) {
		std::cerr << "No OpenCL platforms were found." << std::endl;
		return 1;
	}
	// Other way to do this with checkErr
	checkErr(	platformList.size()!=0 ? CL_SUCCESS : -1, "cl::Platform::get");

	unsigned int ui;
	cl::vector< std::string > platformVendors (platformList.size());
	cl::vector< cl_platform_id > platformIds (platformList.size());
	cl::vector< cl_device_id > deviceIds (platformList.size());
	cl::vector< bool > deviceIsGpu (platformList.size());
	cl::vector< cl_context > contexts (platformList.size());

	// Get platform ids
	//cl_platform_id platform_id;
	checkErr(	clGetPlatformIDs( (cl_uint)(platformList.size()), &(platformIds[0]), NULL), "clGetPlatformIDs");
	// Get device ids
	//checkErr(	clGetDeviceIDs(platform_id, CL_DEVICE_TYPE_GPU, 1, &device_id, NULL);

	for (ui=0;ui<platformList.size();ui++) {
		// Get information from each one of the platforms
		std::string platformVendor;
		platformList[ui].getInfo((cl_platform_info)CL_PLATFORM_VENDOR, &platformVendor);
		std::cerr << "Platform [" << ui <<"] vendor is: " << platformVendor << "\n";
		//cl_context_properties cprops[3] = { CL_CONTEXT_PLATFORM, (cl_context_properties)(platformList[0])(), 0};

		// Get device ids
		cl_device_id device_id;
		// Try GPU first
		err = clGetDeviceIDs(platformIds[ui], CL_DEVICE_TYPE_GPU, 1, &device_id, NULL);
		// If we can't find a GPU, try finding a CPU instead
		if (err == CL_DEVICE_NOT_FOUND) {
			err = clGetDeviceIDs(platformIds[ui], CL_DEVICE_TYPE_CPU, 1, &device_id, NULL);
			if(err < 0) {
				perror("Couldn't access any devices");
				exit(1);   
			}
			deviceIsGpu[ui]=false;
			std::cout << "Device [" << ui<< "] is a CPU" << endl;
		} else {
			deviceIsGpu[ui]=true;
			std::cout << "Device [" << ui<< "] is a GPU" << endl;
			// Get information about the device

			//  CL_DEVICE_AVAILABLE 
			cl_bool isDeviceAvailable=CL_FALSE;
			err = clGetDeviceInfo(device_id, CL_DEVICE_AVAILABLE ,sizeof(cl_bool),&isDeviceAvailable,0 );
			if (isDeviceAvailable==CL_TRUE) {
				printf ("Device is available\n");
			} else {
				printf ("Device is not available\n");
			}

			// CL_DEVICE_COMPILER_AVAILABLE
			cl_bool isCompilerAvailable=CL_FALSE;
			err = clGetDeviceInfo(device_id,CL_DEVICE_COMPILER_AVAILABLE,sizeof(cl_bool),&isCompilerAvailable,0 );
			if (isCompilerAvailable==CL_TRUE) {
				printf ("Compiler is available\n");
			} else {
				printf ("Compiler is not available\n");
			}

			// CL_DEVICE_MAX_COMPUTE_UNITS
			cl_uint maximumComputeUnits;
			err = clGetDeviceInfo(device_id,CL_DEVICE_MAX_COMPUTE_UNITS,sizeof(cl_uint),&maximumComputeUnits,0 );
			printf ("Maximum Compute Units = %u\n",(unsigned int)(maximumComputeUnits));

			// CL_DEVICE_MAX_WORK_GROUP_SIZE
			size_t maximumWorkGroupSize;
			err = clGetDeviceInfo(device_id,CL_DEVICE_MAX_WORK_GROUP_SIZE,sizeof(size_t),&maximumWorkGroupSize,0 );
			printf ("Maximum Work Group Size = %u\n",(unsigned int)(maximumWorkGroupSize));

			// CL_DEVICE_NAME
			char deviceName[256];
			err = clGetDeviceInfo(device_id,CL_DEVICE_NAME,sizeof(char)*256,&deviceName,0 );
			printf ("Device Name = >%s<\n",deviceName);

			// CL_DEVICE_VERSION
			char deviceVersion[256];
			err = clGetDeviceInfo(device_id,CL_DEVICE_VERSION,sizeof(char)*256,&deviceVersion,0 );
			printf ("Device Version = >%s<\n",deviceVersion);

			// CL_DRIVER_VERSION
			char driverVersion[256];
			err = clGetDeviceInfo(device_id,CL_DRIVER_VERSION,sizeof(char)*256,&driverVersion,0 );
			printf ("Driver Version = >%s<\n",driverVersion);

			// CL_DEVICE_GLOBAL_MEM_SIZE
			cl_ulong globalMemorySize;
			err = clGetDeviceInfo(device_id,CL_DEVICE_GLOBAL_MEM_SIZE,sizeof(cl_ulong),&globalMemorySize,0 );
			printf ("Global Memory Size = %lu bytes\n",(unsigned long int)(globalMemorySize));

			// CL_DEVICE_LOCAL_MEM_SIZE
			cl_ulong localMemorySize;
			err = clGetDeviceInfo(device_id,CL_DEVICE_LOCAL_MEM_SIZE,sizeof(cl_ulong),&localMemorySize,0 );
			printf ("Local Memory Size = %lu bytes\n",(unsigned long int)(localMemorySize));

			// CL_DEVICE_LOCAL_MEM_TYPE
			cl_device_local_mem_type type;
			err = clGetDeviceInfo(device_id,CL_DEVICE_LOCAL_MEM_TYPE,sizeof(cl_device_local_mem_type),&type,0 );
			if (type==CL_LOCAL) {
				printf ("Local memory type is dedicated local\n");
			} else if (type==CL_GLOBAL) {
				printf ("Local memory type is global\n");
			}

		}
		deviceIds[ui]=device_id;

		// Create the context
		cl_context context = clCreateContext(NULL, 1, &(deviceIds[ui]), NULL, NULL, &err);
		checkErr( err, "clCreateContext");
		contexts[ui]=context;
	}



/*
	cl::Context contextCPU( CL_DEVICE_TYPE_CPU,cprops,NULL,NULL,&err);
	checkErr(err, "Conext::Context()"); 

	cl::Context contextGPU( CL_DEVICE_TYPE_GPU,cprops,NULL,NULL,&err);
	checkErr(err, "Conext::Context()"); 
*/

}
