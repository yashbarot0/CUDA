#define PROGRAM_FILE "thread3dOpenCl.cl"
#define KERNEL_FUNC "thread3dOpenCl"
#define ARRAY_SIZE_X 4
#define ARRAY_SIZE_Y 6
#define ARRAY_SIZE_Z 8
#define LOCAL_SIZE_X 2;
#define LOCAL_SIZE_Y 2;
#define LOCAL_SIZE_Z 2;

#include <getopt.h>
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

#ifdef MAC
#include <OpenCL/cl.h>
#else
#include <CL/cl.h>
#endif

// Error checking function
void	checkErr			(cl_int err, const char * name);
int	parseArguments			(int argc, char **argv);
void	printUsage			(void);

int array_size[3];
int local_size[3];
int verbose;

void checkErr(cl_int err, const char * name) {
	if (err != CL_SUCCESS) {
		printf("ERROR: %s (%d)\n",name,err);
		exit(EXIT_FAILURE);
	}
}

// Find GPUs or CPUs in the system
void create_device(cl_device_id **devices_ids_ptr_ptr, cl_int *number_of_devices) {
	int i, j;
	char* info;
	size_t infoSize;
	cl_int error;
	cl_uint platformCount;
	cl_platform_id *platforms_ids;
	const char* attributeNames[5] = { "Name", "Vendor","Version", "Profile", "Extensions" };
	const cl_platform_info attributeTypes[5] = { CL_PLATFORM_NAME, CL_PLATFORM_VENDOR,CL_PLATFORM_VERSION, CL_PLATFORM_PROFILE, CL_PLATFORM_EXTENSIONS };
	const int attributeCount = sizeof(attributeNames) / sizeof(char*);
	
	// First, get the number of available platforms
	error = clGetPlatformIDs(5, NULL, &platformCount);
	checkErr(error,"Couldn't identify a platform");

	// Then, get all the available platforms
	platforms_ids = (cl_platform_id*) malloc(sizeof(cl_platform_id) * platformCount);
	clGetPlatformIDs(platformCount, platforms_ids, NULL);

	// Now, for each platform, print all attributes
	if (verbose) {
		for (i = 0; i < platformCount; i++) {
			printf("\n %d. Platform \n", i+1);
			for (j = 0; j < attributeCount; j++) {
				// get platform attribute value size
				clGetPlatformInfo(platforms_ids[i], attributeTypes[j], 0, NULL, &infoSize);
				info = (char*) malloc(infoSize);
				// get platform attribute value
				clGetPlatformInfo(platforms_ids[i], attributeTypes[j], infoSize, info, NULL);
				printf("  %d.%d %-11s: %s\n", i+1, j+1, attributeNames[j], info);
				free(info);
			}
			printf("\n");
		}
	}

	// Now, create a device per found platform - allocate first:
	*devices_ids_ptr_ptr = (cl_device_id*) malloc(sizeof(cl_device_id *) * platformCount);
	*number_of_devices=platformCount;

	for (i=0;i<platformCount;i++) {
		// Get device ids
		cl_device_id device_id;
		// Try GPU first
		error = clGetDeviceIDs(platforms_ids[i], CL_DEVICE_TYPE_GPU, 1, &device_id, NULL);
		// If we can't find a GPU, try finding a GPU instead
		if (error == CL_DEVICE_NOT_FOUND) {
			error = clGetDeviceIDs(platforms_ids[i], CL_DEVICE_TYPE_CPU, 1, &device_id, NULL);
			checkErr(error,"Couldn't access any devices");
			//deviceIsGpu[ui]=false;
			printf("Device [%d] is a CPU\n", i);
		} else {
			//deviceIsGpu[ui]=true;
			printf("Device [%d] is a GPU\n", i);
		}
		checkErr(error,"Couldn't get a device id");
		(*devices_ids_ptr_ptr)[i]=device_id;
	}
	printf("create_device finished successfully\n");

	free(platforms_ids);
	//exit(0);
	return;
}

// Create program from a file and compile it
cl_program build_program(cl_context ctx, cl_device_id dev, const char* filename) {
	cl_program program;
	FILE *program_handle;
	char *program_buffer, *program_log;
	size_t program_size, log_size;
	int err;
	cl_int error;

	// Read program file and place content into buffer
	program_handle = fopen(filename, "r");
	if(program_handle == NULL) {
		perror("Couldn't find the program file");
		exit(1);
	}
	fseek(program_handle, 0, SEEK_END);
	program_size = ftell(program_handle);
	rewind(program_handle);
	program_buffer = (char*)malloc(program_size + 1);
	program_buffer[program_size] = '\0';
	fread(program_buffer, sizeof(char), program_size, program_handle);
	fclose(program_handle);

	// Create program from file
	program = clCreateProgramWithSource(ctx, 1,(const char**)&program_buffer, &program_size, &error);
	checkErr(error,"Couldn't create the program");
	free(program_buffer);

	// Build program
	err = clBuildProgram(program, 0, NULL, NULL, NULL, NULL);
	if(err < 0) {
		// Find size of log and print to std output
		clGetProgramBuildInfo(program, dev, CL_PROGRAM_BUILD_LOG,0, NULL, &log_size);
		program_log = (char*) malloc(log_size + 1);
		program_log[log_size] = '\0';
		clGetProgramBuildInfo(program, dev, CL_PROGRAM_BUILD_LOG,log_size + 1, program_log, NULL);
		printf("%s\n", program_log);
		free(program_log);
		exit(1);
	} else {
		printf ("Program was built sucessfully\n");
	}

	return program;
}

int main (int argc, char *argv[]) {
	// OpenCL structures
	cl_device_id *device_ids;
	cl_context context;
	cl_program program;
	cl_kernel kernel;
	cl_command_queue queue;
	cl_int i,j,k, number_of_devices,error;
	size_t local_size_t[3], global_size[3];

	array_size[0] = ARRAY_SIZE_X;
	array_size[1] = ARRAY_SIZE_Y;
	array_size[2] = ARRAY_SIZE_Z;
	local_size[0] = LOCAL_SIZE_X;
	local_size[1] = LOCAL_SIZE_Y;
	local_size[2] = LOCAL_SIZE_Z;
	verbose=1;

	parseArguments(argc, argv);

	// Data and buffers
	int numberOfElements[3];
	float vector1[array_size[0]*array_size[1]*array_size[2]];
	float vector2[array_size[0]*array_size[1]*array_size[2]];
	float output [array_size[0]*array_size[1]*array_size[2]];
	cl_mem vector1_buffer,vector2_buffer,output_buffer,numberOfElements_buffer;
	cl_int num_groups[3];

	// Initialize data
	for(i=0; i<array_size[0]; i++) {
		for(j=0; j<array_size[1]; j++) {
			for(k=0; k<array_size[2]; k++) {
				output[i*array_size[1]*array_size[2] + j*array_size[2] + k]=0.0;
				vector1[i*array_size[1]*array_size[2] + j*array_size[2] + k]= (float) 2*i;
				vector2[i*array_size[1]*array_size[2] + j*array_size[2] + k]=-(float) i;
			}
		}
	}

	// Create device and context
	create_device(&device_ids,&number_of_devices);

	printf("We have %d device(s)\n",(int)(number_of_devices));

	context = clCreateContext(NULL, number_of_devices, device_ids, NULL, NULL, &error);
	checkErr(error,"Couldn't create a context");

	// Build program
	program = build_program(context, device_ids[0], PROGRAM_FILE); // We can pass device_ids[0] as a device is only needed if building fails

	// Create data buffer
	numberOfElements[0] = (int)(array_size[0]);
	numberOfElements[1] = (int)(array_size[1]);
	numberOfElements[2] = (int)(array_size[2]);
	global_size[0] = numberOfElements[0];
	global_size[1] = numberOfElements[1];
	global_size[2] = numberOfElements[2];
	local_size_t[0] = local_size[0];
	local_size_t[1] = local_size[1];
	local_size_t[2] = local_size[2];

	// Since global_size must be evenly divisable by local_size, we have to do this:
	if ( !(global_size[0]%local_size_t[0]) ) {
		global_size[0] = array_size[0];
	} else {
		global_size[0] = ( ((array_size[0]/local_size_t[0]))*(local_size_t[0]+1));
	}
	if ( !(global_size[1]%local_size_t[1]) ) {
		global_size[1] = array_size[1];
	} else {
		global_size[1] = ( ((array_size[1]/local_size_t[1]))*(local_size_t[1]+1));
	}
	if ( !(global_size[2]%local_size_t[2]) ) {
		global_size[2] = array_size[2];
	} else {
		global_size[2] = ( ((array_size[1]/local_size_t[2]))*(local_size_t[2]+1));
	}

	if (global_size[0]<local_size[0]) global_size[0]=local_size[0];
	if (global_size[1]<local_size[1]) global_size[1]=local_size[1];
	if (global_size[2]<local_size[2]) global_size[2]=local_size[2];

	num_groups[0] = (global_size[0]/local_size_t[0]) + (!(global_size[0]%local_size_t[0])?0:1);
	num_groups[1] = (global_size[1]/local_size_t[1]) + (!(global_size[1]%local_size_t[1])?0:1);
	num_groups[2] = (global_size[2]/local_size_t[2]) + (!(global_size[2]%local_size_t[2])?0:1);

	//num_groups = global_size/local_size_t;
	// (N/dimBlock.x) + (!(N%dimBlock.x)?0:1)
	printf("global_size  = (%d,%d,%d)\n",(int)(global_size[0]),  (int)(global_size[1]),  (int)(global_size[2]));
	printf("local_size   = (%d,%d,%d)\n",(int)(local_size_t[0]), (int)(local_size_t[1]), (int)(local_size[2]));
	printf("num_groups  = (%d,%d,%d)\n", (int)(num_groups[0]),   (int)(num_groups[1]),   (int)(num_groups[2]));

	vector1_buffer = clCreateBuffer(context, CL_MEM_READ_ONLY | CL_MEM_COPY_HOST_PTR, array_size[0] * array_size[1] * array_size[2] * sizeof(float), vector1, &error);
	checkErr(error,"Couldn't create vector1_buffer");

	vector2_buffer = clCreateBuffer(context, CL_MEM_READ_ONLY | CL_MEM_COPY_HOST_PTR, array_size[0] * array_size[1] * array_size[2] * sizeof(float), vector2, &error);
	checkErr(error,"Couldn't create vector2_buffer");

	output_buffer = clCreateBuffer(context, CL_MEM_READ_WRITE | CL_MEM_COPY_HOST_PTR, array_size[0] * array_size[1] * array_size[2] * sizeof(float), output, &error);
	checkErr(error,"Couldn't create output_buffer");

	numberOfElements_buffer= clCreateBuffer(context, CL_MEM_READ_ONLY | CL_MEM_COPY_HOST_PTR, 3*sizeof(int), numberOfElements, &error);
	checkErr(error,"Couldn't create numberOfElements_buffer");

	// Create a command queue
	queue = clCreateCommandQueue(context, device_ids[0], 0, &error);
	checkErr(error,"Couldn't create a command queue");

	// Create a kernel
	kernel = clCreateKernel(program, KERNEL_FUNC, &error);
	checkErr(error,"Couldn't create a kernel");

	// Create kernel arguments to the global or constant memory - as usual:
	error =  clSetKernelArg(kernel, 0, sizeof(cl_mem), &vector1_buffer);
	error |= clSetKernelArg(kernel, 1, sizeof(cl_mem), &vector2_buffer);
	error |= clSetKernelArg(kernel, 2, sizeof(cl_mem), &output_buffer);
	error |= clSetKernelArg(kernel, 3, sizeof(cl_mem), &numberOfElements_buffer);
	checkErr(error,"Couldn't create a kernel argument");

	// Enqueue kernel
	error = clEnqueueNDRangeKernel(queue, kernel, 3, NULL, global_size, local_size_t, 0, NULL, NULL); 
	checkErr(error,"Couldn't enqueue the kernel");

	// Read the kernel's output
//	error = clEnqueueReadBuffer(queue, sum_buffer, CL_TRUE, 0,sizeof(sum), sum, 0, NULL, NULL);
//	checkErr(error,"Couldn't read the sum buffer");
	error = clEnqueueReadBuffer(queue, output_buffer, CL_TRUE, 0,array_size[0] * array_size[1] * array_size[2] * sizeof(float), output, 0, NULL, NULL);
	checkErr(error,"Couldn't read the output buffer");
/*
	for(j=0; j<num_groups; j++) {
		printf("sum[%d]=%f\n",j,sum[j]);
	}
*/

	// Check result
	int passed=1;
	for(i=0; i<array_size[0]; i++) {
		for(j=0; j<array_size[1]; j++) {
			for(k=0; k<array_size[2]; k++) {
				if (verbose)
					printf("vector1[%3d][%3d][%3d](%4.4f) +vector2[%3d][%3d][%3d]=(%4.4f) = output[%3d][%3d][%3d](%f)\n",
						i,j,k,vector1[i*array_size[1]*array_size[2] + j*array_size[2] + k],
						i,j,k,vector2[i*array_size[1]*array_size[2] + j*array_size[2] + k],
						i,j,k,output [i*array_size[1]*array_size[2] + j*array_size[2] + k]);

				if ( fabs(	vector1[i*array_size[1]*array_size[2] + j*array_size[2] + k]+
						vector2[i*array_size[1]*array_size[2] + j*array_size[2] + k]-
						output [i*array_size[1]*array_size[2] + j*array_size[2] + k])>1.E-03) passed=0;
			}
		}

	}
	if (passed==0) {
		printf("Test was NOT successful\n");
	} else {
		printf("Test was successful\n");
	}

   // Deallocate resources
   clReleaseKernel(kernel);
   clReleaseMemObject(vector1_buffer);
   clReleaseMemObject(vector2_buffer);
   clReleaseMemObject(output_buffer);
   clReleaseMemObject(numberOfElements_buffer);
   clReleaseCommandQueue(queue);
   clReleaseProgram(program);
   clReleaseContext(context);

	free(device_ids);
   return 0;
}
void printUsage () {
	printf("thread3dOpenCl program\n");
	printf("by: Jose Mauricio Refojo <refojoj@tcd.ie>\n");
	printf("This program will calculate the vector sum of two given vectors in OpenCl\n");
	printf("usage:\n");
	printf("thread3dOpenCl.out [options]\n");
	printf("      -n   value   : will set the x size of the matrix to value (default: %d)\n",(int)(ARRAY_SIZE_X));
	printf("      -m   value   : will set the y size of the matrix to value (default: %d)\n",(int)(ARRAY_SIZE_Y));
	int my_local_size_x=LOCAL_SIZE_X;
	printf("      -x   value   : will set the local size of the work groups to value (default:%d)\n",my_local_size_x);
	int my_local_size_y=LOCAL_SIZE_Y;
	printf("      -y   value   : will set the local size of the work groups to value (default:%d)\n",my_local_size_y);
	printf("      -h           : will show this usage\n");
	printf("      -v           : will activate the verbose mode  (default: no)\n");
	printf("     \n");
}

int parseArguments (int argc, char *argv[]) {
	int c;

	while ((c = getopt (argc, argv, "n:m:hvx:y:")) != -1) {
		switch(c) {
//			case 'n':
//				array_size_x = atof(optarg); break;
//			case 'm':
//				array_size_y = atof(optarg); break;
//			case 'x':
//				local_size_x = atof(optarg); break;
//			case 'y':
//				local_size_y = atof(optarg); break;
			case 'h':
				printUsage(); exit(0);
			case 'v':
				verbose = 1; break;
			default:
				fprintf(stderr, "Invalid option given\n");
				printUsage();
				return -1;
		}
	}
	return 0;
}
