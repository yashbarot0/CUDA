#define PROGRAM_FILE "addVectors.cl"
#define KERNEL_FUNC "addVectors"

#define ARRAY_SIZE 524288
//#define ARRAY_SIZE 10

#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

#include <iostream>
#include <vector>

#ifdef MAC
#include <OpenCL/cl.h>
#else
#include <CL/cl.h>
#endif

inline void checkErr(cl_int err, const char * name) {
	if (err != CL_SUCCESS) {
		std::cerr << "ERROR: " << name << " (" << err << ")" << std::endl;
//		exit(EXIT_FAILURE);
	}
}

// Find a GPU or CPU associated with the first available platform
cl_device_id create_device() {
	cl_platform_id platform;
	cl_device_id dev;
	int err;

	// Identify a platform
	err = clGetPlatformIDs(1, &platform, NULL);
	if(err < 0) {
		perror("Couldn't identify a platform");
		exit(1);
	} 

	// Access a device
	err = clGetDeviceIDs(platform, CL_DEVICE_TYPE_GPU, 1, &dev, NULL);
	if(err == CL_DEVICE_NOT_FOUND) {
		err = clGetDeviceIDs(platform, CL_DEVICE_TYPE_CPU, 1, &dev, NULL);
	}
	if(err < 0) {
		perror("Couldn't access any devices");
		exit(1);   
	}

	return dev;
}

// Create program from a file and compile it
cl_program build_program(cl_context context, cl_device_id dev, const char* filename) {
	cl_program program;
	FILE *program_handle;
	char *program_buffer, *program_log;
	size_t program_size, log_size;
	int err;

 	// Read program text file and place content into buffer (char*)
	program_handle = fopen(filename, "r");
	if(program_handle == NULL) {
		perror("Couldn't find the program file");
		exit(1);
	}
	fseek(program_handle, 0, SEEK_END);
	program_size = ftell(program_handle);
	rewind(program_handle);
	program_buffer = (char*)malloc(program_size + 1);
	program_buffer[program_size] = '\0';
	fread(program_buffer, sizeof(char), program_size, program_handle);
	fclose(program_handle);

	// Create program from file
	program = clCreateProgramWithSource(context, 1, 
		(const char**)&program_buffer, &program_size, &err);
	if(err < 0) {
		perror("Couldn't create the program");
		exit(1);
	}
	free(program_buffer);

	// Build program
	err = clBuildProgram(program, 0, NULL, NULL, NULL, NULL);
	if(err < 0) {
		// Find size of log and print to std output
		clGetProgramBuildInfo(program, dev, CL_PROGRAM_BUILD_LOG, 
			0, NULL, &log_size);
		program_log = (char*) malloc(log_size + 1);
		program_log[log_size] = '\0';
		clGetProgramBuildInfo(program, dev, CL_PROGRAM_BUILD_LOG, 
			log_size + 1, program_log, NULL);
		printf("%s\n", program_log);
		free(program_log);
		exit(1);
	}
	return program;
}

int main (void) {
	// OpenCL structures
	cl_device_id device;
	cl_context context;
	cl_program program;
	cl_kernel kernel;
	cl_command_queue queue;
	cl_int i, err;
	size_t local_size, global_size;

	// Data and buffers
	int problem_size_cpu = ARRAY_SIZE;
	float data1_cpu[ARRAY_SIZE];
	float data2_cpu[ARRAY_SIZE];
	float final_cpu[ARRAY_SIZE];
	cl_mem data1_gpu,data2_gpu;
	cl_mem final_gpu;	// Final result
	cl_mem size_gpu;	// Total problem size
	cl_int num_groups;

	// Initialize data
	for(i=0; i<problem_size_cpu; i++) {
		data1_cpu[i] = (1.0f*i)+1;
		data2_cpu[i] = (2.0f*i)+2;
		final_cpu[i] = 0.0;
	}

	// Create device and context
	device = create_device();
	context = clCreateContext(NULL, 1, &device, NULL, NULL, &err);
	if(err < 0) {
		perror("Couldn't create a context");
		exit(1);   
	}

	// Build program
	program = build_program(context, device, PROGRAM_FILE);

	// Set up work items and work group sizes:
	global_size = problem_size_cpu;	// This is the total size of the problem
	local_size = 1024;
	num_groups = global_size/local_size;

	printf("global_size = %u  local_size=%u  num_groups=%d\n",(unsigned int)(global_size),(unsigned int)(local_size),(int)num_groups);

	// Create global data buffer
	data1_gpu  = clCreateBuffer(context, CL_MEM_READ_ONLY  | CL_MEM_COPY_HOST_PTR, ARRAY_SIZE * sizeof(float), data1_cpu, &err);
	data2_gpu  = clCreateBuffer(context, CL_MEM_READ_ONLY  | CL_MEM_COPY_HOST_PTR, ARRAY_SIZE * sizeof(float), data2_cpu, &err);
	final_gpu  = clCreateBuffer(context, CL_MEM_READ_WRITE | CL_MEM_COPY_HOST_PTR, ARRAY_SIZE * sizeof(float), final_cpu, &err);
	size_gpu   = clCreateBuffer(context, CL_MEM_READ_ONLY  | CL_MEM_COPY_HOST_PTR, sizeof(int), &problem_size_cpu, &err);
	if(err < 0) {
		perror("Couldn't create a buffer");
		exit(1);   
	};

	// Create a command queue
	queue = clCreateCommandQueue(context, device, 0, &err);
	if(err < 0) {
		perror("Couldn't create a command queue");
		exit(1);   
	};

	// Create a kernel
	kernel = clCreateKernel(program, KERNEL_FUNC, &err);
	checkErr(err, "Couldn't create a kernel (1)");

	if(err < 0) {
		perror("Couldn't create a kernel");
		exit(1);
	};

	// Create kernel arguments
	err = clSetKernelArg(kernel, 0, sizeof(cl_mem), &data1_gpu);
	err |= clSetKernelArg(kernel, 1, sizeof(cl_mem), &data2_gpu);
	err |= clSetKernelArg(kernel, 2, sizeof(cl_mem), &final_gpu);
	err |= clSetKernelArg(kernel, 3, sizeof(cl_mem), &size_gpu);
	if(err < 0) {
		perror("Couldn't create a kernel argument");
		exit(1);
	}

	// Enqueue kernel
	err = clEnqueueNDRangeKernel(queue, kernel, 1, NULL, &global_size, &local_size, 0, NULL, NULL); 
	if(err < 0) {
		perror("Couldn't enqueue the kernel");
		exit(1);
	}

	// Read the kernel's output
	err = clEnqueueReadBuffer(queue, final_gpu, CL_TRUE, 0, ARRAY_SIZE * sizeof(float), final_cpu, 0, NULL, NULL);

	// final_cpu

	if(err < 0) {
		perror("Couldn't read the buffer");
		exit(1);
	}

	// Check result
	for(i=0; i<problem_size_cpu; i++) {
		if ( fabs( (data1_cpu[i]+data2_cpu[i])-final_cpu[i] ) > 1.E-06 ) {
			printf("data1_cpu[%d]=%f + data2_cpu[%d]=%f = final_cpu[%d]=%f\n",i,data1_cpu[i],i,data2_cpu[i],i,final_cpu[i]);
		}
	}

	// Deallocate resources
	clReleaseKernel(kernel);

	clReleaseMemObject(data1_gpu);
	clReleaseMemObject(data2_gpu);
	clReleaseMemObject(final_gpu);
	clReleaseMemObject(size_gpu);

	clReleaseCommandQueue(queue);
	clReleaseProgram(program);
	clReleaseContext(context);
        return 0;
}
